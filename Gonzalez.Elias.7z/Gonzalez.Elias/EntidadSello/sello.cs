﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadSello
{
    public class sello
    {
        public static string mensaje;
        public static ConsoleColor color;
        
        public static void imprimir()
        {
            if(sello.tryParse(sello.mensaje, out mensaje))
            {
                sello.mensaje = sello.formatoMensaje();
                Console.ForegroundColor = sello.color;
                Console.WriteLine("{0}", sello.mensaje);
                Console.ForegroundColor = ConsoleColor.White;
            }

        }
        public static void borrar()
        {
            Console.Clear();
        }
        private static string formatoMensaje()
        {
            int cantidad;
            string mensajeFormado=null;

            cantidad= sello.mensaje.Length;
            for (int i = 0; i < cantidad + 2; i++)
            {
                mensajeFormado += "*";
            }
            mensajeFormado += "\n"+"*" + sello.mensaje + "*"+"\n";
            for (int i = 0; i < cantidad + 2; i++)
            {
                mensajeFormado += "*";
            }
            return (mensajeFormado);
        }
        public static bool tryParse(string mensaje, out string salida)
        {
            bool retorno=false;
            int cantidad;

            cantidad = mensaje.Length;
            if (cantidad != 0)
            {
                retorno = true;
                
            }
            salida = mensaje;

            return (retorno);
        }



    }
}
