﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_01
{
    class Program
    {
        static void Main(string[] args)
        {
            float numero;
            float resultado=0;
            float promedio;
            float max=0;
            float min=0;
            int i;

            for (i = 0; i < 5; i++)
            {

                Console.WriteLine("ingrese el numero:");

                numero = float.Parse(Console.ReadLine());

                resultado = resultado+numero;

                if (i == 0)
                {
                    max = numero;
                    min = numero;
                }
                else
                {
                    if (numero > max)
                    {
                        max = numero;
                    }
                    else if (numero < min)
                    {
                        min = numero;
                    }
                }

            }

            promedio = resultado / 5;

            Console.WriteLine("maximo:{0} minimo:{1} promedio:{2}",max,min,promedio);

            Console.ReadLine();
        }
    }
}
