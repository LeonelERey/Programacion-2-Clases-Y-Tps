﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_02
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero;
            double numCuadrado;
            double numCubo;

            Console.WriteLine("ingrese un numero:");
            numero = int.Parse(Console.ReadLine());

            while (numero == 0)
            {
                Console.WriteLine("ERROR.¡Reingrese un numero!:");
                numero = int.Parse(Console.ReadLine());
            }

            numCuadrado = Math.Pow(numero, 2);
            numCubo = Math.Pow(numero, 3);

            Console.WriteLine("cuadrado:{1} cubo:{0}",numCubo,numCuadrado);
            Console.ReadLine();
        }
    }
}
