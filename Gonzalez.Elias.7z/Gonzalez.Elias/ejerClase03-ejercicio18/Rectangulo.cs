﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejerClase03_ejercicio18
{
    class Rectangulo
    {
        private float area;
        private float perimetro;
        private Punto vertice1;
        private Punto vertice2;
        private Punto vertice3;
        private Punto vertice4;

        public Rectangulo(Punto _vertice1, Punto _vertice3)
        {
            this.vertice2 = new Punto(vertice1.getX(), vertice3.getY());
            this.vertice4 = new Punto(vertice1.getX(), vertice3.getY());
            this.vertice1 = _vertice1;
            this.vertice3 = _vertice3;

        }
        public float perimetro(float num1, float num2, float num3, float num4)
        {
            float perimetro=0;

            area = num1 + num2 + num3 + num4;

            return perimetro;
        }
    }
}
