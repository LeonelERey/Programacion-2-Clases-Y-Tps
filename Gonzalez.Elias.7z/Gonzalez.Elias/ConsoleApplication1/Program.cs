﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejerClase02
{
    class Program
    {
        static void Main(string[] args)
        {
            EntidadSello.sello.mensaje = "HOLA GENTE COMO LES VA.";
            EntidadSello.sello.color = ConsoleColor.Red;
            EntidadSello.sello.imprimir();
            Console.ReadLine();
            EntidadSello.sello.borrar();
            EntidadSello.sello.mensaje = "";
            EntidadSello.sello.color = ConsoleColor.Green;
            EntidadSello.sello.imprimir();
            Console.ReadLine();
            Console.WriteLine ("Oprima una tecla para salir!!!.");
            Console.ReadLine();
        }
    }
}
