﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejerClase04_ejercicio29
{
    class Equipo
    {
        private short cantidadJugadores;
        private List<Jugador> jugador;
        private string nombre;

        private Equipo()
        {
            this.cantidadJugadores = 5;
            this.jugador=new List<Jugador>();
            this.nombre="sin nombre";
        }
        public Equipo(short cantidad, string nombre):this()
        {
            this.cantidadJugadores = cantidad;
            this.nombre = nombre;
        }
        public static bool operator +(Equipo x, Jugador y)
        {
            bool retorno = true;
            int i;
            if (x.jugador.Count == x.cantidadJugadores)
                retorno = false;
            else
            for (i = 0; i < x.cantidadJugadores; i++)
            {
                if (x.jugador[i] == y)
                    retorno = false;
            }

            return retorno;
        }
        //public List<Jugador> getJugadores()
        //{
        //    return ;
        //}
    }
}
