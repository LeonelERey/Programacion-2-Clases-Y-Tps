﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_03
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero;
            int i;
            int j;

            Console.WriteLine("ingrese un numero:");
            numero = int.Parse(Console.ReadLine());

            for (i = 0; i <= numero; i++)
            {
               
            }
        }
    }
}
